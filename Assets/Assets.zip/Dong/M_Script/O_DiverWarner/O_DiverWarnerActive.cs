using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class O_DiverWarnerActive : M_State
{
    public O_DiverWarnerActive(M_Base @base, M_StateMachine stateMachine, string aniboolname) : base(@base, stateMachine, aniboolname)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();
    }
}
