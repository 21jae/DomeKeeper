using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class S_MouseInput : MonoBehaviour
{
    /*Vector3 MousePosition;
    public LayerMask wahtisGround;

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawSphere(MousePosition, 0.2f);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            MousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Collider2D overCollider2d = Physics2D.OverlapCircle(MousePosition, 0.01f, wahtisGround);
            if (overCollider2d != null)
            {
                overCollider2d.transform.GetComponent<S_MapGenerator>().MakeDot(MousePosition);
            }
        }
    }*/
}
