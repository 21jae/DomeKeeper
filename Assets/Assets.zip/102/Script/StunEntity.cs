using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StunEntity : MonoBehaviour
{
    [SerializeField] public float Atk;
    [SerializeField] public float Speed;
}
